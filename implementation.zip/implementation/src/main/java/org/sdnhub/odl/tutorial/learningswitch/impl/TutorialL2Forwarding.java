/*
 * Copyright (C) 2016 Barbara Valera Muros
 * 
 * This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package org.sdnhub.odl.tutorial.learningswitch.impl;

import java.nio.ByteBuffer;
//import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.md.sal.common.api.data.LogicalDatastoreType;
import org.opendaylight.controller.sal.binding.api.NotificationProviderService;
import org.opendaylight.controller.sal.binding.api.RpcProviderRegistry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.yang.types.rev100924.MacAddress;
import org.opendaylight.yang.gen.v1.urn.opendaylight.action.types.rev131112.action.list.Action;
import org.opendaylight.yang.gen.v1.urn.opendaylight.action.types.rev131112.action.action.OutputActionCaseBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.action.types.rev131112.action.action.output.action._case.OutputActionBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.action.types.rev131112.action.list.ActionBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.action.types.rev131112.action.list.ActionKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.FlowCapableNode;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.FlowId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.Table;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.TableKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.table.Flow;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.table.FlowBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.table.FlowKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.flow.InstructionsBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.flow.MatchBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.instruction.instruction.ApplyActionsCaseBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.instruction.instruction.apply.actions._case.ApplyActionsBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.instruction.list.Instruction;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.instruction.list.InstructionBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.instruction.list.InstructionKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.Nodes;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.Node;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.NodeKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingListener;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketReceived;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.TransmitPacketInput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.TransmitPacketInputBuilder;
import org.opendaylight.yangtools.concepts.Registration;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.sdnhub.odl.tutorial.utils.GenericTransactionUtils;
import org.sdnhub.odl.tutorial.utils.PacketParsingUtils;
import org.sdnhub.odl.tutorial.utils.inventory.InventoryUtils;
import org.sdnhub.odl.tutorial.utils.openflow13.MatchUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;

public class TutorialL2Forwarding  implements AutoCloseable, PacketProcessingListener {
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());
    private final static long FLOOD_PORT_NUMBER = 0xfffffffbL;

    //Members specific to this class
    private Map<String, NodeConnectorId> macTable = new HashMap <String, NodeConnectorId>();
    private Map<String, hostData> hostTable = new HashMap <String, hostData>();
	private String function = "switch"; 
	String payloadRouter = "";
	byte [] payloadRouterB;
	byte [] permanentReply = new byte [10];
        
    //Members related to MD-SAL operations
	private List<Registration> registrations;
	private DataBroker dataBroker;
	private PacketProcessingService packetProcessingService;
	
    public TutorialL2Forwarding(DataBroker dataBroker, NotificationProviderService notificationService, RpcProviderRegistry rpcProviderRegistry) {
    	//Store the data broker for reading/writing from inventory store
        this.dataBroker = dataBroker;

        //Get access to the packet processing service for making RPC calls later
        this.packetProcessingService = rpcProviderRegistry.getRpcService(PacketProcessingService.class);        

    	//List used to track notification (both data change and YANG-defined) listener registrations
    	this.registrations = Lists.newArrayList(); 

        //Register this object for receiving notifications when there are PACKET_INs
        registrations.add(notificationService.registerNotificationListener(this));
  	}

    @Override
    public void close() throws Exception {
        for (Registration registration : registrations) {
        	registration.close();
        }
        registrations.clear();
    }

    @Override
	public void onPacketReceived(PacketReceived notification) {
    	LOG.trace("Received packet notification {}", notification.getMatch());

        NodeConnectorRef ingressNodeConnectorRef = notification.getIngress();
        NodeRef ingressNodeRef = InventoryUtils.getNodeRef(ingressNodeConnectorRef);
        NodeConnectorId ingressNodeConnectorId = InventoryUtils.getNodeConnectorId(ingressNodeConnectorRef);
        NodeId ingressNodeId = InventoryUtils.getNodeId(ingressNodeConnectorRef);

        // Useful to create it beforehand 
    	NodeConnectorId floodNodeConnectorId = InventoryUtils.getNodeConnectorId(ingressNodeId, FLOOD_PORT_NUMBER);
    	NodeConnectorRef floodNodeConnectorRef = InventoryUtils.getNodeConnectorRef(floodNodeConnectorId);

        /*
         * Logic:
         * 0. Ignore LLDP packets
         * 1. If behaving as "hub", perform a PACKET_OUT with FLOOD action
         * 2. Else if behaving as "learning switch",
         *    2.1. Extract MAC addresses
         *    2.2. Update MAC table with source MAC address
         *    2.3. Lookup in MAC table for the target node connector of dst_mac
         *         2.3.1 If found, 
         *               2.3.1.1 perform FLOW_MOD for that dst_mac through the target node connector
         *               2.3.1.2 perform PACKET_OUT of this packet to target node connector
         *         2.3.2 If not found, perform a PACKET_OUT with FLOOD action
         */

    	//Ignore LLDP packets, or you will be in big trouble
        byte[] etherTypeRaw = PacketParsingUtils.extractEtherType(notification.getPayload());
        int etherType = (0x0000ffff & ByteBuffer.wrap(etherTypeRaw).getShort());
        if (etherType == 0x88cc) {
        	return;
        }
        // Hub implementation
        if (function.equals("hub")) {
        	LOG.info("bvalera - Hub");
        	//flood packet (1)
            packetOut(ingressNodeRef, floodNodeConnectorRef, notification.getPayload());
        } else {
            byte[] payload = notification.getPayload();
            byte[] dstMacRaw = PacketParsingUtils.extractDstMac(payload);
            PacketParsingUtils.extractEtherType(payload); 
            byte[] srcMacRaw = PacketParsingUtils.extractSrcMac(payload);
            LOG.info("bvalera - Learning Switch");
            StringBuilder payloadB = new StringBuilder();        
            for (byte b : payload) {
                payloadB.append(String.format("%02X ", b));
            }
            final String payloadBytes = payloadB.toString();
            LOG.info("bvalera - Packet payload in bytes is {}", payloadBytes);
            
            //Extract MAC addresses (2.1)
            String srcMac = PacketParsingUtils.rawMacToString(srcMacRaw);
            String dstMac = PacketParsingUtils.rawMacToString(dstMacRaw);

            //Learn source MAC address (2.2)
            this.macTable.put(srcMac, ingressNodeConnectorId);

            //Lookup destination MAC address in table (2.3)
            NodeConnectorId egressNodeConnectorId = this.macTable.get(dstMac) ;
            
            //IPv6            
            boolean boolOut = true;
            int offset = 0;
            byte nextHeader = 0;
            LOG.info("bvalera - Ethernet Type {}", etherType);
            if (etherType == 34525){ //0x86DD
            	LOG.info("bvalera - IPv6");
            	offset = 14;
            	nextHeader = payload[offset + 6];
            	if (nextHeader == 58){ //0x3a
            		
            		//srcAddress = payload[offset + 8, offset + 23];
            		String srcAddress = "";
            		srcAddress = String.format("%02x", payload[offset + 8]);
                    for(int i = offset + 9; i < offset + 24; i++){
                    	srcAddress = srcAddress + ":" + String.format("%02x", payload[i]);           
                    }
                    int c = 0;
                    byte [] srcAddressB = new byte [16];
                    for(int a = (offset + 8); a < (offset + 24); a++){
                    	srcAddressB[c] = payload[a];
                    	c++;
                    }
                    
                    LOG.info("bvalera - Source Address {}", srcAddress);
                    LOG.info("bvalera - Source MAC {}", srcMac);
                    
            		//destAddress = payload[offset + 24, offset + 39];
            		String dstAddress = "";
            		dstAddress = String.format("%02x", payload[offset + 24]);
                    for(int i = offset + 25; i < offset + 40; i++){
                    	dstAddress = dstAddress + ":" + String.format("%02x", payload[i]);           
                    }
                    
                    int d = 0;
                    byte [] dstAddressB = new byte [16];
                    for(int a = (offset + 24); a < (offset + 25); a++){
                    	dstAddressB[d] = payload[a];
                    	d++;
                    }
                    
                    LOG.info("bvalera - Destination Address {}", dstAddress);
                    LOG.info("bvalera - Destination MAC {}", dstMac);
            		
            		offset += 40;
            		
            		switch (payload[offset]){
            		case (byte)133: //0x85
            			// Router solicitation
            			LOG.info("bvalera - Router Solicitation");
            			if (payloadRouterB != null){
            				packetOut(ingressNodeRef, ingressNodeConnectorRef, payloadRouterB);
                            LOG.info("bvalera - Controller sends RA itself.");
                            boolOut = false;
            			}
            			break;
            		case (byte)134: //0x86
            			// Router advertisement
            			LOG.info("bvalera - Router Advertisement");
            			hostData routerData = hostTable.get(srcAddress);
            			if (routerData == null){
            				createNode(srcAddress, srcMac, notification.getPayload(), srcMacRaw, srcAddressB);
            				LOG.info("bvalera - Router has been added to the table.");            				
            				String prefixNet = "";
            				prefixNet = String.format("%02x", payload[offset + 32]);
            				for (int i = offset + 33; i < offset + 48; i++){
            					prefixNet = prefixNet + ":" + String.format("%02x", payload[i]);
            				}
            				LOG.info("bvalera - Network Prefix {}", prefixNet);            				
            			} else {            				
            				LOG.info("bvalera - Router was already on the table.");
            				final long oneDay = 86400000;
            				if (System.currentTimeMillis() > (oneDay + (routerData.getDate()))){
            					createNode(srcAddress, srcMac, notification.getPayload(), srcMacRaw, srcAddressB);
                				LOG.info("bvalera - Router entry was older than 24h");
            				} else {
            					boolOut = false;
            					LOG.info("bvalera - Router adding date was recent");
            				}
            			}            			
            			payloadRouter = String.format("%02x", payload[14]);
        				for (int i = 15; i < offset + 56; i++){
        					payloadRouter = payloadRouter + " " + String.format("%02x", payload[i]);
        				}
        				payloadRouterB = notification.getPayload();        				
        				LOG.info("bvalera - Payload Router {}", payloadRouter);
            			break;
            		case (byte)135: //0x87
            			// Neighbor solicitation
            			LOG.info("bvalera - Neighbor Solicitation");
	        			updateNode(srcAddress, srcMac, notification.getPayload(), srcMacRaw, srcAddressB);
	        			hostData neighborDest = hostTable.get(dstAddress);
	        			if (neighborDest != null){
	        				packetOut(ingressNodeRef, ingressNodeConnectorRef, neighborDest.getNodePayload());
                            LOG.info("bvalera - Controller sends NA itself.");
                            boolOut = false;
	        			}
            			break;
            		case (byte)136: //0x88
            			// Neighbor advertisement
            			LOG.info("bvalera - Neighbor Advertisement");
            			hostData nodeData = hostTable.get(srcAddress);
            			if (nodeData == null){
            				createNode(srcAddress, srcMac, notification.getPayload(), srcMacRaw, srcAddressB);
            				LOG.info("bvalera - Host has been added to the table.");
            			} else {
            				LOG.info("bvalera - Host was already on the table.");
            				if (System.currentTimeMillis() > (86400000 + (nodeData.getDate()))){
            					createNode(srcAddress, srcMac, notification.getPayload(), srcMacRaw, srcAddressB);
                				LOG.info("bvalera - Host entry was older than 24h");
            				} else {
            					boolOut = false;
            					LOG.info("bvalera - Host adding date was recent.");
            				}
            			}
            			break;
            		case (byte)137: //0x89
            			// Redirect to a better router
            			LOG.info("bvalera - Redirect to a better router");
            			break;
            		default:
            			LOG.info("bvalera - Not a case option");
            		}
            	}
            } else if (etherType == 2054){
            	LOG.info("bvalera - ARP - IPv4");
            	String srcAddress = "";
        		srcAddress = String.format("%02x", payload[28]);
                for(int i = 29; i < 32; i++){
                	srcAddress = srcAddress + ":" + String.format("%02x", payload[i]);           
                }
                
                byte [] srcAddressB = new byte [4];
                int c = 0;
                for(int a = 28; a < 32; a++){
                	srcAddressB[c] = payload[a];
                	c++;
                }
                
                LOG.info("bvalera - Source Address {}", srcAddress);
                LOG.info("bvalera - Source MAC {}", srcMac);
                
                String dstAddress = "";
        		dstAddress = String.format("%02x", payload[38]);
                for(int i = 39; i < 42; i++){
                	dstAddress = dstAddress + ":" + String.format("%02x", payload[i]);           
                }
                
                int d = 0;
                byte [] dstAddressB = new byte [4];
                for(int a = 38; a < 42; a++){
                	dstAddressB[d] = payload[a];
                	d++;
                }
                
                LOG.info("bvalera - Destination Adress {}", dstAddress);
                LOG.info("bvalera - Destination MAC {}", dstMac);
                
                switch (payload[21]){
                case (byte)01:
                	// Request
                	LOG.info("bvalera - ARP Request");
	                updateNode(srcAddress, srcMac, notification.getPayload(), srcMacRaw, srcAddressB);
	    			hostData neighborDest = hostTable.get(dstAddress);
	    			if (neighborDest != null){
	    				byte[] payloadReply = new byte[42];
	    				System.arraycopy(srcMacRaw, 0, payloadReply, 0, srcMacRaw.length);
	    				int offsetARP = srcMacRaw.length;
	    				LOG.info("bvalera - offsetARP {}", offsetARP);
	    				System.arraycopy(neighborDest.getMacByte(), 0, payloadReply, offsetARP, neighborDest.getMacByte().length);
	    				offsetARP += neighborDest.getMacByte().length;
	    				LOG.info("bvalera - offsetARP {}", offsetARP);
	    				//String permanent = "08 06 00 01 08 00 06 04 00 02";	    		        	    		        
	    		        //System.arraycopy(convertToBytes(permanent.split(" ")), 0, payloadReply, offsetARP, convertToBytes(permanent.split(" ")).length);
	    				System.arraycopy(permanentReply, 0, payloadReply, offsetARP, permanentReply.length);
	    				//offsetARP += convertToBytes(permanent.split(" ")).length;
	    				offsetARP += permanentReply.length;
	    				LOG.info("bvalera - offsetARP {}", offsetARP);
	    				System.arraycopy(neighborDest.getMacByte(), 0, payloadReply, offsetARP, neighborDest.getMacByte().length);
	    				offsetARP += neighborDest.getMacByte().length;
	    				LOG.info("bvalera - offsetARP {}", offsetARP);
	    				System.arraycopy(dstAddressB, 0, payloadReply, offsetARP, dstAddressB.length);
	    				offsetARP += dstAddressB.length;
	    				LOG.info("bvalera - offsetARP {}", offsetARP);
	    				System.arraycopy(srcMacRaw, 0, payloadReply, offsetARP, srcMacRaw.length);
	    				offsetARP += srcMacRaw.length;
	    				LOG.info("bvalera - offsetARP {}", offsetARP);
	    				System.arraycopy(srcAddressB, 0, payloadReply, offsetARP, srcAddressB.length);
	    				StringBuilder payloadReplyB = new StringBuilder();        
	    	            for (byte r : payloadReply) {
	    	                payloadReplyB.append(String.format("%02X ", r));
	    	            }
	    	            final String payloadReplyBytes = payloadReplyB.toString();
	    	            LOG.info("bvalera - Packet payload reply in bytes is {}", payloadReplyBytes);
	    				packetOut(ingressNodeRef, ingressNodeConnectorRef, payloadReply);
	                    LOG.info("bvalera - Controller sends Reply itself.");
	                    boolOut = false;
	    			}
                break;
                case (byte)02:
                	// Reply
                	LOG.info("bvalera - ARP Reply");
                	updateNode(srcAddress, srcMac, notification.getPayload(), srcMacRaw, srcAddressB);
                	System.arraycopy(payload, 12, permanentReply, 0, 10);
                break;
                }
            } else if (etherType == 2048){//0x0800
            	LOG.info("bvalera - IPv4");
            	
            	String srcAddress = "";
        		srcAddress = String.format("%02x", payload[26]);//12
                for(int i = 27; i < 30; i++){//13 16
                	srcAddress = srcAddress + ":" + String.format("%02x", payload[i]);           
                }
                
                int c = 0;
                byte [] srcAddressB = new byte [4];
                for(int a = 26; a < 30; a++){
                	srcAddressB[c] = payload[a];
                	c++;
                }
                
                LOG.info("bvalera - Source Address {}", srcAddress);
                LOG.info("bvalera - Destination MAC {}", srcMac);
                
                updateNode(srcAddress, srcMac, notification.getPayload(), srcMacRaw, srcAddressB);
            }
            
          //If found (2.3.1) 
            if (boolOut){
            	LOG.info("bvalera - packetOut with boolOut true");
            	if (egressNodeConnectorId != null) {
                    programL2Flow(ingressNodeId, dstMac, ingressNodeConnectorId, egressNodeConnectorId);
                    NodeConnectorRef egressNodeConnectorRef = InventoryUtils.getNodeConnectorRef(egressNodeConnectorId);
                    packetOut(ingressNodeRef, egressNodeConnectorRef, payload);
                } else {
                	//2.3.2 Flood packet
                    packetOut(ingressNodeRef, floodNodeConnectorRef, payload);
                }
            }            
          ////////////////////////////////////////////////////////////////////  
        }
    }

	private void packetOut(NodeRef egressNodeRef, NodeConnectorRef egressNodeConnectorRef, byte[] payload) {
        Preconditions.checkNotNull(packetProcessingService);
        LOG.debug("Flooding packet of size {} out of port {}", payload.length, egressNodeConnectorRef);

        //Construct input for RPC call to packet processing service
        TransmitPacketInput input = new TransmitPacketInputBuilder()
                .setPayload(payload)
                .setNode(egressNodeRef)
                .setEgress(egressNodeConnectorRef)
                .build();
        packetProcessingService.transmitPacket(input);       
    }    
	
    private void programL2Flow(NodeId nodeId, String dstMac, NodeConnectorId ingressNodeConnectorId, NodeConnectorId egressNodeConnectorId) {

    	/* Programming a flow involves:
    	 * 1. Creating a Flow object that has a match and a list of instructions,
    	 * 2. Adding Flow object as an augmentation to the Node object in the inventory. 
    	 * 3. FlowProgrammer module of OpenFlowPlugin will pick up this data change and eventually program the switch.
    	 */

        //Creating match object
        MatchBuilder matchBuilder = new MatchBuilder();
        MatchUtils.createEthDstMatch(matchBuilder, new MacAddress(dstMac), null);
        MatchUtils.createInPortMatch(matchBuilder, ingressNodeConnectorId);

        // Instructions List Stores Individual Instructions
        InstructionsBuilder isb = new InstructionsBuilder();
        List<Instruction> instructions = Lists.newArrayList();
        InstructionBuilder ib = new InstructionBuilder();
        ApplyActionsBuilder aab = new ApplyActionsBuilder();
        ActionBuilder ab = new ActionBuilder();
        List<Action> actionList = Lists.newArrayList();

        // Set output action
        OutputActionBuilder output = new OutputActionBuilder();
        output.setOutputNodeConnector(egressNodeConnectorId);
        output.setMaxLength(65535); //Send full packet and No buffer
        ab.setAction(new OutputActionCaseBuilder().setOutputAction(output.build()).build());
        ab.setOrder(0);
        ab.setKey(new ActionKey(0));
        actionList.add(ab.build());

        // Create Apply Actions Instruction
        aab.setAction(actionList);
        ib.setInstruction(new ApplyActionsCaseBuilder().setApplyActions(aab.build()).build());
        ib.setOrder(0);
        ib.setKey(new InstructionKey(0));
        instructions.add(ib.build());

        // Create Flow
        FlowBuilder flowBuilder = new FlowBuilder();
        flowBuilder.setMatch(matchBuilder.build());

        String flowId = "L2_Rule_" + dstMac;
        flowBuilder.setId(new FlowId(flowId));
        FlowKey key = new FlowKey(new FlowId(flowId));
        flowBuilder.setBarrier(true);
        flowBuilder.setTableId((short)0);
        flowBuilder.setKey(key);
        flowBuilder.setPriority(32768);
        flowBuilder.setFlowName(flowId);
        flowBuilder.setHardTimeout(0);
        flowBuilder.setIdleTimeout(0);
        flowBuilder.setInstructions(isb.setInstruction(instructions).build());

        InstanceIdentifier<Flow> flowIID = InstanceIdentifier.builder(Nodes.class)
                .child(Node.class, new NodeKey(nodeId))
                .augmentation(FlowCapableNode.class)
                .child(Table.class, new TableKey(flowBuilder.getTableId()))
                .child(Flow.class, flowBuilder.getKey())
                .build();
        GenericTransactionUtils.writeData(dataBroker, LogicalDatastoreType.CONFIGURATION, flowIID, flowBuilder.build(), true);
    }
    
    public class hostData{
    	String IP;
    	String MAC;
    	byte [] nodePayload;
    	byte [] srcMacB;
    	byte [] srcIpB;
    	long date;
    	
    	public void setIp(String ipAdd){
    		this.IP = ipAdd;
    	}
    	
    	public void setMac(String macAdd){
    		this.MAC = macAdd;
    	}
    	
    	public void setDate(){
    		this.date = System.currentTimeMillis();
    	}
    	
    	public void setPayload(byte[] neighborPay){
    		this.nodePayload = neighborPay;
    	}
    	
    	public void setMacB(byte[] macByte){
    		this.srcMacB = macByte;
    	}
    	
    	public void setIpB(byte[] ipByte){
    		this.srcIpB = ipByte;
    	}
    	
    	public String getIp(){
    		return IP;
    	}
    	
    	public String getMac(){
    		return MAC;
    	}
    	
    	public byte[] getNodePayload(){
    		return nodePayload;
    	}
    	
    	public byte[] getMacByte(){
    		return srcMacB;
    	}
    	
    	public byte[] getIpByte(){
    		return srcIpB;
    	}
    	
    	public long getDate(){
    		return date;
    	}
    	
    }
    
    public void updateNode(String sourceIP, String sourceMAC, byte[] sourcePayload, byte[] sourceMacB, byte[]sourceIpB){
    	hostData nodeData = hostTable.get(sourceIP);
    	if (nodeData == null){
    		createNode(sourceIP, sourceMAC, sourcePayload, sourceMacB, sourceIpB);
    		LOG.info("bvalera - Host has been added to the table.");
    	} else {
			if (System.currentTimeMillis() > (120000 + (nodeData.getDate()))){//2min
				createNode(sourceIP, sourceMAC, sourcePayload, sourceMacB, sourceIpB);
				LOG.info("bvalera - Host has been updated.");
			}
		}
    }
    
    public void createNode(String sourceIP, String sourceMAC, byte[] sourcePayload, byte[]sourceMacB, byte[]sourceIpB){
    	hostData nodeData = new hostData();
		nodeData.setIp(sourceIP);
		nodeData.setMac(sourceMAC);
		nodeData.setDate();
		nodeData.setPayload(sourcePayload);
		nodeData.setMacB(sourceMacB);
		nodeData.setIpB(sourceIpB);
		hostTable.put(sourceIP, nodeData);
    }
}