package org.opendaylight.yang.gen.v1.urn.sdnhub.odl.tutorial.tapapp.tapapp.impl.rev150604;

public final class $YangModelBindingProvider implements org.opendaylight.yangtools.yang.binding.YangModelBindingProvider {

    public org.opendaylight.yangtools.yang.binding.YangModuleInfo getModuleInfo() {
        return $YangModuleInfoImpl.getInstance();
    }
}
