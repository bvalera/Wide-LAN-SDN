package org.opendaylight.yang.gen.v1.urn.sdnhub.odl.tutorial.learning._switch.learning._switch.impl.rev150605;

public final class $YangModelBindingProvider implements org.opendaylight.yangtools.yang.binding.YangModelBindingProvider {

    public org.opendaylight.yangtools.yang.binding.YangModuleInfo getModuleInfo() {
        return $YangModuleInfoImpl.getInstance();
    }
}
